package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.FileReader;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

public class Rec00Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rec00);


    }


//    public boolean authenticate(javax.servlet.http.HttpServletRequest request, javax.xml.xpath.XPath xpath, org.w3c.dom.Document doc) throws XPathExpressionException {
//        String username = req.getParameter("username");
//        String password = req.getParameter("password");
//        XPathFactory factory = XPathFactory.newInstance();
//        XPath xpath = factory.newXPath();
//        File file = new File("/usr/webappdata/users.xml");
//        InputSource src = new InputSource(new FileInputStream(file));
//        XPathExpression expr = xpath.compile("//users[username/text()=' " +
//                username + " ' and password/text()=' " + password + " ']/id/text()");
//        String id = expr.evaluate(src);
//    }

//    XPath xPath = XPathFactory.newInstance().newXPath();
//    InputSource inputXml = new InputSource(xmlFile);
//    String username = request.getParameter("username");
//    String password = request.getParameter("password");
//
//    //code to validate function for inputs received i.e "username" and "password"
//
//    String query = "//users/user[name/text()='" + username +
//            "' and pass/text()='" + password + "']" +
//            "/secret/text()";
//    String result = (String)xPath.evaluate(query, inputXml, XPathConstants.STRING);
}