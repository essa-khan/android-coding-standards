package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void rule06(View view) {
        Intent intent = new Intent(this, Rule06Activity.class);
        startActivity(intent);
    }

    public void rule07(View view) {
        Intent intent = new Intent(this, Rule07Activity.class);
        startActivity(intent);
    }

    public void rule00(View view) {
        Intent intent = new Intent(this, Rule00Activity.class);
        startActivity(intent);
    }

    public void rec00(View view) {
        Intent intent = new Intent(this, Rec00Activity.class);
        startActivity(intent);
    }

    public void rec01(View view) {
        Intent intent = new Intent(this, Rec01Activity.class);
        startActivity(intent);
    }


}