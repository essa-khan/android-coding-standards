package com.example.dummyvillebank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.util.Log;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public int loginHandler(View v){
        // Get username and password from the login
        TextView userName = findViewById(R.id.usernameLogin);
        TextView passWord = findViewById(R.id.passwordLogin);
        TextView errorMsg = findViewById(R.id.errorMsg);

        // The input from the user
        String uName = userName.getText().toString();
        String pWord = passWord.getText().toString();

        Log.d("Username => ", uName);
        Log.d("Password => ", pWord);

        if(uName.equals("admin") && pWord.equals("password")){
            userName.setText("");
            passWord.setText("");
            errorMsg.setVisibility(View.INVISIBLE);
            Intent i = new Intent(this, UserHomeActivity.class);
            startActivity(i);
            return 0;
        }
        else{
            errorMsg.setVisibility(View.VISIBLE);
            return -1;
        }
    }
}